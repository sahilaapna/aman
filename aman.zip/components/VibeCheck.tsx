import React, { useRef, useState, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Camera, RefreshCw, AlertCircle, CheckCircle2, X } from 'lucide-react';

const STRESS_LEVELS = [
  { max: 20, emoji: "😌", label: "Zen", color: "text-emerald-500" },
  { max: 40, emoji: "🙂", label: "Calm", color: "text-teal-500" },
  { max: 60, emoji: "😐", label: "Neutral", color: "text-yellow-500" },
  { max: 80, emoji: "😰", label: "Stressed", color: "text-orange-500" },
  { max: 100, emoji: "🤯", label: "Panic", color: "text-red-500" },
];

const VibeCheck: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<{score: number, analysis: string, advice: string} | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [snapshot, setSnapshot] = useState<string | null>(null);

  // Automatically attach stream to video element when it mounts or stream changes
  useEffect(() => {
    if (videoRef.current && stream && !snapshot) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(e => console.log("Video play interrupted", e));
    }
  }, [stream, snapshot]);

  const startCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(s);
      setError(null);
      setSnapshot(null);
      setResult(null);
    } catch (err) {
      console.error("Camera error", err);
      setError("Could not access camera. Please allow permissions.");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(t => t.stop());
      setStream(null);
    }
  };

  const resetAnalysis = () => {
    setSnapshot(null);
    setResult(null);
    setError(null);
  };

  // Setup camera on mount/unmount
  React.useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  const analyzeVibe = async () => {
    if (!videoRef.current || !canvasRef.current || isAnalyzing) return;
    
    const video = videoRef.current;
    
    // Check if video is ready
    if (video.readyState !== 4) { // HAVE_ENOUGH_DATA
        setError("Camera is warming up. Please wait a moment...");
        return;
    }

    if (video.videoWidth === 0 || video.videoHeight === 0) {
        setError("Camera stream not valid yet. Try again.");
        return;
    }
    
    setIsAnalyzing(true);
    setResult(null);
    setError(null);

    // Capture frame
    const canvas = canvasRef.current;
    
    // Resize for speed (max width 640px)
    const scale = Math.min(1, 640 / video.videoWidth);
    canvas.width = video.videoWidth * scale;
    canvas.height = video.videoHeight * scale;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) {
        setIsAnalyzing(false);
        return;
    }
    
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Convert to base64 (JPEG 0.8 quality for balance)
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
    const base64Data = dataUrl.split(',')[1];
    
    if (!base64Data) {
        setError("Failed to capture image.");
        setIsAnalyzing(false);
        return;
    }
    
    setSnapshot(dataUrl); // Show the frozen frame
    video.pause(); // Stop video to indicate capture

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    {
                        inlineData: {
                            mimeType: 'image/jpeg',
                            data: base64Data
                        }
                    },
                    {
                        text: "Analyze the facial expression in this image to detect stress levels. Return a JSON object with 'score' (0-100 where 0 is very calm and 100 is extremely stressed), 'analysis' (short description of the mood), and 'advice' (one sentence tip to relax)."
                    }
                ]
            },
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        score: { type: Type.NUMBER },
                        analysis: { type: Type.STRING },
                        advice: { type: Type.STRING }
                    }
                }
            }
        });

        const rawText = response.text;
        if (!rawText) throw new Error("No response from AI");

        // Robust JSON extraction
        const firstOpen = rawText.indexOf('{');
        const lastClose = rawText.lastIndexOf('}');
        
        if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
            const cleanJson = rawText.substring(firstOpen, lastClose + 1);
            const json = JSON.parse(cleanJson);
            setResult(json);
        } else {
            // Try parsing directly if clean
            try {
                const json = JSON.parse(rawText);
                setResult(json);
            } catch {
                throw new Error("Invalid response format");
            }
        }
        
    } catch (e: any) {
        console.error("Analysis failed", e);
        // Clean error message
        const msg = e.message || "Could not analyze vibe.";
        if (msg.includes("400") || msg.includes("INVALID_ARGUMENT")) {
             setError("Analysis failed: The image could not be processed. Please try again with better lighting.");
        } else {
             setError("Could not analyze vibe. Please try again.");
        }
        resetAnalysis(); // Reset on error so user can try again
    } finally {
        setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Instant Vibe Check</h2>
        <p className="text-slate-500">Use Gemini Flash to get an instant reading on your stress levels based on facial micro-expressions.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Camera Feed */}
        <div className="space-y-4">
            <div 
                className={`relative aspect-[4/3] bg-white/50 backdrop-blur rounded-3xl overflow-hidden shadow-xl border border-white/60 group cursor-pointer ${isAnalyzing ? 'ring-4 ring-teal-200' : ''}`}
                onClick={!isAnalyzing && !result ? analyzeVibe : undefined}
            >
                {/* Snapshot Overlay */}
                {snapshot ? (
                    <img src={snapshot} className="w-full h-full object-cover transform scale-x-[-1]" alt="Analysis Snapshot" />
                ) : (
                    <video ref={videoRef} className="w-full h-full object-cover transform scale-x-[-1]" playsInline muted />
                )}
                
                <canvas ref={canvasRef} className="hidden" />
                
                {!stream && (
                    <div className="absolute inset-0 flex items-center justify-center bg-slate-100 text-slate-400">
                        {error ? <span className="text-red-500 px-4 text-center">{error}</span> : "Camera Off"}
                    </div>
                )}

                {/* Hover hint */}
                {!snapshot && stream && !isAnalyzing && (
                    <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                         <span className="text-slate-800 font-semibold bg-white/90 px-5 py-2.5 rounded-full shadow-lg">Tap to Analyze</span>
                    </div>
                )}
            </div>
            
            <div className="flex space-x-2">
                {result ? (
                     <button
                        onClick={resetAnalysis}
                        className="w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center space-x-2 bg-slate-200 hover:bg-slate-300 text-slate-700 transition-all shadow-sm"
                    >
                        <X />
                        <span>Retake</span>
                    </button>
                ) : (
                    <button
                        onClick={analyzeVibe}
                        disabled={isAnalyzing || !stream}
                        className={`w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center space-x-2 transition-all shadow-lg shadow-teal-500/20 ${
                            isAnalyzing 
                            ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                            : 'bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-white'
                        }`}
                    >
                        {isAnalyzing ? (
                            <>
                                <RefreshCw className="animate-spin" />
                                <span>Analyzing...</span>
                            </>
                        ) : (
                            <>
                                <Camera />
                                <span>Snap & Analyze</span>
                            </>
                        )}
                    </button>
                )}
            </div>
            {error && <p className="text-red-500 text-sm text-center bg-red-50 p-2 rounded-lg border border-red-100">{error}</p>}
        </div>

        {/* Results */}
        <div className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/60 shadow-xl shadow-slate-200/50 p-8 flex flex-col justify-center min-h-[400px]">
            {result ? (
                <div className="space-y-8 animate-fade-in w-full">
                    {/* Stress Meter */}
                    <div className="text-center w-full">
                        <h3 className="text-xl font-semibold text-slate-700 mb-6">Current Stress Level</h3>
                        
                        {/* Smileys Row */}
                        <div className="flex justify-between items-end mb-4 px-1">
                            {STRESS_LEVELS.map((level, idx) => {
                                // Logic to determine active range
                                const prevMax = idx === 0 ? -1 : STRESS_LEVELS[idx-1].max;
                                const isActive = result.score > prevMax && result.score <= level.max;
                                // Fallback for 100 or edge cases
                                const isLast = idx === STRESS_LEVELS.length - 1 && result.score > level.max; 
                                
                                const activeState = isActive || isLast;

                                return (
                                    <div key={idx} className={`flex flex-col items-center transition-all duration-500 ${activeState ? 'scale-125 opacity-100 transform -translate-y-2' : 'opacity-30 scale-90 grayscale'}`}>
                                        <span className="text-4xl mb-2 filter drop-shadow-sm">{level.emoji}</span>
                                        <span className={`text-[10px] font-bold uppercase tracking-wider ${activeState ? level.color : 'text-slate-400'}`}>
                                            {level.label}
                                        </span>
                                    </div>
                                );
                            })}
                        </div>

                        {/* Gauge Bar */}
                        <div className="relative h-6 bg-slate-200 rounded-full shadow-inner mb-2 overflow-hidden">
                            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-emerald-300 via-yellow-300 to-red-300 opacity-40"></div>
                            
                            {/* Needle/Indicator */}
                            <div 
                                className="absolute top-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg border-4 border-white flex items-center justify-center transition-all duration-1000 ease-out z-10"
                                style={{ left: `${Math.min(Math.max(result.score, 0), 100)}%`, transform: 'translate(-50%, -50%)' }}
                            >
                                <div className={`w-2 h-2 rounded-full ${result.score > 80 ? 'bg-red-500' : result.score > 40 ? 'bg-yellow-500' : 'bg-emerald-500'}`}></div>
                            </div>
                        </div>
                        
                        <p className="text-slate-500 text-sm font-medium">
                            Score: <span className="text-slate-800 font-bold">{result.score}/100</span>
                        </p>
                    </div>
                    
                    {/* Analysis & Advice */}
                    <div className="bg-white/50 rounded-2xl p-6 border border-white/50 shadow-sm">
                        <h4 className="text-lg font-medium text-slate-800 mb-3 leading-snug">{result.analysis}</h4>
                        <div className="flex items-start space-x-3 mt-4 bg-teal-50 p-4 rounded-xl border border-teal-100">
                            <CheckCircle2 className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                            <p className="text-teal-800 text-sm">{result.advice}</p>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="text-center text-slate-400 space-y-4">
                    <div className="w-20 h-20 mx-auto rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center">
                        <AlertCircle className="w-10 h-10 opacity-30 text-slate-400" />
                    </div>
                    <p>Tap the video or click the button to analyze your vibe.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default VibeCheck;