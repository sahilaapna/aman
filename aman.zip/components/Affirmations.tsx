import React, { useState, useRef } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { Play, Pause, Sparkles, Volume2, RefreshCw } from 'lucide-react';
import { base64ToArrayBuffer } from '../utils/audioUtils';

const Affirmations: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [affirmation, setAffirmation] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  const generateAndSpeak = async () => {
    setLoading(true);
    setAffirmation(null);
    setIsPlaying(false);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        // Step 1: Generate the affirmation text
        const textResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: "Write a short, powerful, 2-sentence positive affirmation to reduce stress. Make it unique.",
        });
        const text = textResponse.text || "You are calm, capable, and resilient.";
        setAffirmation(text);

        // Step 2: Generate Speech
        const ttsResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-tts',
            contents: { parts: [{ text: `Say gently: ${text}` }] },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Fenrir' } // Deep soothing voice
                    }
                }
            }
        });

        const base64Audio = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        
        if (base64Audio) {
            playAudio(base64Audio);
        }

    } catch (e) {
        console.error(e);
        alert("Failed to generate affirmation.");
    } finally {
        setLoading(false);
    }
  };

  const playAudio = async (base64: string) => {
    if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    
    const ctx = audioContextRef.current;
    const arrayBuffer = base64ToArrayBuffer(base64);
    
    // Manual PCM Decode (Int16 -> Float32)
    const dataInt16 = new Int16Array(arrayBuffer);
    const numChannels = 1;
    const buffer = ctx.createBuffer(numChannels, dataInt16.length, 24000); 
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) {
        channelData[i] = dataInt16[i] / 32768.0;
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.onended = () => setIsPlaying(false);
    source.start();
    setIsPlaying(true);
  };

  return (
    <div className="max-w-3xl mx-auto flex flex-col items-center justify-center min-h-[60vh] text-center space-y-12">
        <div className="space-y-3">
            <h2 className="text-4xl font-bold text-slate-800 mb-2">
                Daily Calm
            </h2>
            <p className="text-slate-500 text-lg">
                Generate a unique positive affirmation read by our AI engine.
            </p>
        </div>

        <div className="relative group w-full max-w-xl">
            {/* Ambient Glow */}
            <div className="absolute -inset-2 bg-gradient-to-r from-teal-200 to-blue-200 rounded-3xl blur-xl opacity-40 group-hover:opacity-60 transition duration-1000"></div>
            
            <div className="relative bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl p-10 flex flex-col items-center justify-center shadow-2xl shadow-slate-200/50 min-h-[250px]">
                {affirmation ? (
                    <blockquote className="text-3xl font-serif italic text-slate-700 leading-relaxed mb-6 drop-shadow-sm">
                        "{affirmation}"
                    </blockquote>
                ) : (
                    <div className="text-slate-400 flex flex-col items-center space-y-3">
                        <Sparkles className="w-10 h-10 opacity-40" />
                        <span className="font-medium">Ready to receive positivity?</span>
                    </div>
                )}
                
                {isPlaying && (
                     <div className="flex space-x-1.5 mt-4 h-6 items-end">
                        <div className="w-1.5 bg-teal-400 animate-[bounce_1s_infinite] h-3 rounded-full"></div>
                        <div className="w-1.5 bg-teal-400 animate-[bounce_1.2s_infinite] h-6 rounded-full"></div>
                        <div className="w-1.5 bg-teal-400 animate-[bounce_0.8s_infinite] h-4 rounded-full"></div>
                     </div>
                )}
            </div>
        </div>

        <button
            onClick={generateAndSpeak}
            disabled={loading || isPlaying}
            className={`
                px-10 py-5 rounded-full font-bold text-lg flex items-center space-x-3 transition-all transform hover:scale-105 active:scale-95 shadow-xl shadow-teal-500/20
                ${loading 
                    ? 'bg-slate-200 text-slate-500' 
                    : 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white hover:shadow-teal-500/40'
                }
            `}
        >
            {loading ? (
                <>
                    <RefreshCw className="animate-spin w-5 h-5" />
                    <span>Generating...</span>
                </>
            ) : (
                <>
                    <Volume2 className="w-5 h-5" />
                    <span>Generate & Listen</span>
                </>
            )}
        </button>
    </div>
  );
};

export default Affirmations;