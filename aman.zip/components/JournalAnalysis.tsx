import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Upload, FileVideo, Check, AlertCircle, Sparkles } from 'lucide-react';
import { blobToBase64 } from '../utils/audioUtils';

const JournalAnalysis: React.FC = () => {
    const [file, setFile] = useState<File | null>(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [result, setResult] = useState<string | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
            setResult(null);
        }
    };

    const analyzeVideo = async () => {
        if (!file) return;
        setAnalyzing(true);
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const base64Data = await blobToBase64(file);
            
            const response = await ai.models.generateContent({
                model: 'gemini-3-pro-preview',
                contents: {
                    parts: [
                        {
                            inlineData: {
                                mimeType: file.type,
                                data: base64Data
                            }
                        },
                        {
                            text: "Watch this video diary entry. Provide a summary of the user's emotional state, identify key stressors mentioned, and offer a paragraph of supportive advice."
                        }
                    ]
                }
            });
            
            setResult(response.text || "No analysis generated.");
            
        } catch (e) {
            console.error(e);
            alert("Video too large or analysis failed. Try a short clip (< 10s).");
        } finally {
            setAnalyzing(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div>
                <h2 className="text-3xl font-bold text-slate-800 mb-2">Video Journal Analysis</h2>
                <p className="text-slate-500">Upload a short video diary entry. Aman will analyze your emotional arc and provide insights.</p>
            </div>

            <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl p-10 border-dashed border-2 flex flex-col items-center justify-center space-y-4 hover:bg-white/80 transition-colors shadow-lg shadow-slate-200/50">
                <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center shadow-sm">
                    {file ? <Check className="text-emerald-500 w-10 h-10" /> : <FileVideo className="text-blue-500 w-10 h-10" />}
                </div>
                
                <div className="text-center">
                     <label htmlFor="video-upload" className="cursor-pointer">
                        <span className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-full font-medium transition-colors shadow-md shadow-blue-500/20 inline-block">
                            Select Video
                        </span>
                        <input 
                            id="video-upload" 
                            type="file" 
                            accept="video/*" 
                            className="hidden" 
                            onChange={handleFileChange} 
                        />
                     </label>
                     <p className="text-sm text-slate-400 mt-3 font-medium">{file ? file.name : "Supports MP4, MOV (Max 10MB for demo)"}</p>
                </div>
            </div>

            {file && (
                <button
                    onClick={analyzeVideo}
                    disabled={analyzing}
                    className={`w-full py-4 rounded-2xl font-bold text-lg transition-all shadow-lg ${
                        analyzing ? 'bg-slate-200 text-slate-400' : 'bg-gradient-to-r from-teal-600 to-blue-600 text-white hover:from-teal-500 hover:to-blue-500 shadow-blue-500/20'
                    }`}
                >
                    {analyzing ? "Processing Video..." : "Analyze Journal Entry"}
                </button>
            )}

            {result && (
                <div className="bg-white/70 backdrop-blur-xl rounded-3xl p-8 border border-white/60 shadow-xl shadow-slate-200/50 animate-fade-in">
                    <h3 className="text-xl font-semibold text-slate-800 mb-4 flex items-center space-x-2">
                        <Sparkles className="w-5 h-5 text-teal-500" />
                        <span>Journal Insights</span>
                    </h3>
                    <div className="prose prose-slate prose-lg max-w-none">
                        <p className="whitespace-pre-wrap text-slate-600 leading-relaxed">{result}</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default JournalAnalysis;