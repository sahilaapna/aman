import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Mic, MicOff, Video as VideoIcon, VideoOff, Power, Activity } from 'lucide-react';
import ThreeAvatar from './ThreeAvatar';
import { float32ToInt16, base64ToArrayBuffer, pcmToAudioBuffer, blobToBase64 } from '../utils/audioUtils';

const LiveCompanion: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCamOn, setIsCamOn] = useState(true);
  const [audioVolume, setAudioVolume] = useState(0); // 0-1 for visualizer
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sessionRef = useRef<Promise<any> | null>(null); 
  const nextStartTimeRef = useRef<number>(0);
  const frameIntervalRef = useRef<number | null>(null);
  const isConnectedRef = useRef<boolean>(false);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const connect = async () => {
    try {
      if (!process.env.API_KEY) {
        alert("API Key not found in environment.");
        return;
      }

      // Initialize Audio Contexts
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      // Explicitly resume
      await inputAudioContextRef.current.resume();
      await audioContextRef.current.resume();

      // Get User Media
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          channelCount: 1,
          sampleRate: 16000
        }, 
        video: {
            width: 640,
            height: 480
        }
      });
      streamRef.current = stream;

      // Setup Video Preview
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Start connection
      isConnectedRef.current = true;
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: async () => {
            console.log("Session Opened");
            setIsConnected(true);
            isConnectedRef.current = true;
            
            // --- Audio Input Setup ---
            if (inputAudioContextRef.current) {
               const source = inputAudioContextRef.current.createMediaStreamSource(stream);
               // Buffer size 4096 for stability
               const processor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
               
               processor.onaudioprocess = (e) => {
                 if (!isMicOn || !isConnectedRef.current) return;
                 const inputData = e.inputBuffer.getChannelData(0);
                 const int16Data = float32ToInt16(inputData);
                 
                 let binary = '';
                 const bytes = new Uint8Array(int16Data.buffer);
                 const len = bytes.byteLength;
                 for (let i = 0; i < len; i++) {
                   binary += String.fromCharCode(bytes[i]);
                 }
                 const base64Data = window.btoa(binary);
   
                 sessionPromise.then(session => {
                   if (!isConnectedRef.current) return;
                   try {
                     session.sendRealtimeInput({
                       media: {
                         mimeType: 'audio/pcm;rate=16000',
                         data: base64Data
                       }
                     });
                   } catch (err) {
                     console.error("Error sending audio input:", err);
                   }
                 }).catch(err => {
                     console.error("Session promise error:", err);
                 });
               };
   
               source.connect(processor);
               processor.connect(inputAudioContextRef.current.destination);
            }

            // --- Video Input Setup ---
            startVideoStreaming(sessionPromise);
          },
          onmessage: async (message: LiveServerMessage) => {
             // Handle Audio Output
             const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
             if (base64Audio && audioContextRef.current) {
                if (audioContextRef.current.state === 'suspended') {
                    await audioContextRef.current.resume();
                }
                
                setIsModelSpeaking(true);
                // Reset flag after a short delay if no more audio comes (simple heuristic)
                setTimeout(() => setIsModelSpeaking(false), 500);

                const audioData = base64ToArrayBuffer(base64Audio);
                const int16Data = new Int16Array(audioData);
                const audioBuffer = pcmToAudioBuffer(int16Data, audioContextRef.current, 24000);
                
                // Calculate volume for visualizer
                const channelData = audioBuffer.getChannelData(0);
                let sum = 0;
                // Sample some points for volume
                for(let i=0; i<channelData.length; i+=10) {
                    sum += Math.abs(channelData[i]);
                }
                const avg = sum / (channelData.length / 10);
                setAudioVolume(Math.min(avg * 5, 1)); // Amplify a bit

                const source = audioContextRef.current.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(audioContextRef.current.destination);
                
                // Schedule playback
                const currentTime = audioContextRef.current.currentTime;
                const startTime = Math.max(nextStartTimeRef.current, currentTime);
                source.start(startTime);
                nextStartTimeRef.current = startTime + audioBuffer.duration;
             }
          },
          onclose: () => {
            console.log("Session Closed");
            setIsConnected(false);
            isConnectedRef.current = false;
          },
          onerror: (err) => {
            console.error("Session Error", err);
            disconnect();
          }
        },
        config: {
            responseModalities: [Modality.AUDIO],
            systemInstruction: `You are Aman, a warm, empathetic, and peaceful stress-relief companion. 
            Your goal is to detect stress in the user's voice and facial expressions. 
            If they look or sound stressed, gently ask about it, offer comforting words, or crack a gentle joke to cheer them up.
            Be conversational, listen actively, and speak with a soothing tone. 
            Keep your responses concise and snappy to keep the conversation flowing naturally.
            You are a 3D avatar on a screen, so acknowledge that if relevant.`,
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
            }
        }
      });
      
      sessionRef.current = sessionPromise;

    } catch (e) {
      console.error("Connection failed", e);
      alert("Failed to connect to Aman.");
      isConnectedRef.current = false;
    }
  };

  const startVideoStreaming = (sessionPromise: Promise<any>) => {
    if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
    
    frameIntervalRef.current = window.setInterval(() => {
        if (!videoRef.current || !canvasRef.current || !isCamOn || !isConnectedRef.current) return;
        
        const video = videoRef.current;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        
        if (ctx && video.videoWidth > 0) {
            canvas.width = video.videoWidth * 0.5; // Scale down for performance
            canvas.height = video.videoHeight * 0.5;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            canvas.toBlob(async (blob) => {
                if(blob && isConnectedRef.current) {
                    const base64 = await blobToBase64(blob);
                    sessionPromise.then(session => {
                        if (!isConnectedRef.current) return;
                        try {
                            session.sendRealtimeInput({
                                media: {
                                    mimeType: 'image/jpeg',
                                    data: base64
                                }
                            });
                        } catch(e) {
                            console.error("Error sending video frame", e);
                        }
                    }).catch(e => console.error("Session promise failed during video send", e));
                }
            }, 'image/jpeg', 0.6);
        }
    }, 1000); // Send frame every 1 second
  };

  const disconnect = () => {
    isConnectedRef.current = false;
    
    // Stop all tracks
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    // Close Audio Contexts
    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    
    // Clear Intervals
    if (frameIntervalRef.current) {
        clearInterval(frameIntervalRef.current);
        frameIntervalRef.current = null;
    }
    
    // Reset state
    setIsConnected(false);
    setIsModelSpeaking(false);
    setAudioVolume(0);
    nextStartTimeRef.current = 0;
  };

  return (
    <div className="h-full flex flex-col space-y-4 max-w-6xl mx-auto">
      <div className="flex-none flex justify-between items-center mb-2">
        <div>
           <h2 className="text-3xl font-bold text-slate-800 tracking-tight">Live Companion</h2>
           <p className="text-slate-500">Speak freely. Aman is here to listen and help.</p>
        </div>
        <div className="flex items-center space-x-2">
            {!isConnected ? (
                <button
                    onClick={connect}
                    className="flex items-center space-x-2 bg-teal-600 hover:bg-teal-500 text-white px-6 py-3 rounded-full font-semibold transition-all shadow-lg shadow-teal-500/30"
                >
                    <Power size={20} />
                    <span>Connect</span>
                </button>
            ) : (
                <button
                    onClick={disconnect}
                    className="flex items-center space-x-2 bg-red-100 hover:bg-red-200 text-red-600 border border-red-200 px-6 py-3 rounded-full font-semibold transition-all"
                >
                    <Power size={20} />
                    <span>End Session</span>
                </button>
            )}
        </div>
      </div>

      {/* Main Visual Area */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-6 min-h-[400px]">
        {/* Avatar Section */}
        <div className="md:col-span-2 relative h-full">
            <ThreeAvatar volume={audioVolume} isModelSpeaking={isModelSpeaking} isUserSpeaking={false} />
            
            {/* Overlay Controls */}
            {isConnected && (
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center space-x-4 bg-white/30 backdrop-blur-xl px-6 py-3 rounded-2xl border border-white/40 shadow-xl">
                    <button
                        onClick={() => setIsMicOn(!isMicOn)}
                        className={`p-3 rounded-full transition-colors ${isMicOn ? 'bg-white text-slate-700 shadow-sm' : 'bg-red-50 text-red-500'}`}
                    >
                        {isMicOn ? <Mic size={20} /> : <MicOff size={20} />}
                    </button>
                    <div className="h-8 w-[1px] bg-slate-400/30"></div>
                    <button
                        onClick={() => setIsCamOn(!isCamOn)}
                        className={`p-3 rounded-full transition-colors ${isCamOn ? 'bg-white text-slate-700 shadow-sm' : 'bg-red-50 text-red-500'}`}
                    >
                        {isCamOn ? <VideoIcon size={20} /> : <VideoOff size={20} />}
                    </button>
                </div>
            )}
        </div>

        {/* User Self View & Metrics */}
        <div className="flex flex-col space-y-6">
            <div className="relative aspect-video bg-white/50 backdrop-blur-sm rounded-3xl overflow-hidden border border-white/60 shadow-lg shadow-slate-200/50 group">
                <video 
                    ref={videoRef} 
                    className={`w-full h-full object-cover transform scale-x-[-1] transition-opacity ${isCamOn ? 'opacity-100' : 'opacity-0'}`} 
                    muted 
                    playsInline 
                />
                {!isCamOn && (
                    <div className="absolute inset-0 flex items-center justify-center text-slate-400">
                        <VideoOff size={32} />
                    </div>
                )}
                <div className="absolute top-3 left-3 bg-white/80 backdrop-blur px-3 py-1 rounded-full text-[10px] text-slate-600 font-bold tracking-wider shadow-sm">
                    YOU
                </div>
                {/* Hidden canvas for processing */}
                <canvas ref={canvasRef} className="hidden" />
            </div>

            <div className="flex-1 bg-white/60 backdrop-blur-md rounded-3xl p-6 border border-white/60 shadow-lg shadow-slate-200/50 flex flex-col justify-center items-center text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-teal-50 flex items-center justify-center shadow-inner">
                    <Activity className={`w-8 h-8 ${isConnected ? 'text-teal-500 animate-pulse' : 'text-slate-300'}`} />
                </div>
                <div>
                    <h3 className="text-slate-800 font-semibold text-lg">Stress Monitor</h3>
                    <p className="text-sm text-slate-500 mt-2 leading-relaxed">
                        {isConnected 
                            ? "Analyzing voice tone and facial cues in real-time..." 
                            : "Connect to start monitoring"}
                    </p>
                </div>
                {isConnected && (
                    <div className="w-full bg-slate-200 rounded-full h-2 mt-4 overflow-hidden">
                        <div className="bg-gradient-to-r from-teal-400 to-cyan-400 h-full w-2/3 animate-[pulse_3s_ease-in-out_infinite]"></div>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default LiveCompanion;