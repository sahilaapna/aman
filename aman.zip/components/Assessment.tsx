import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Check, ChevronRight, ClipboardCheck, RefreshCw, AlertTriangle } from 'lucide-react';

const QUESTIONS = [
  "Over the last 2 weeks, how often have you been bothered by feeling down, depressed, or hopeless?",
  "How often have you had little interest or pleasure in doing things?",
  "How often have you felt nervous, anxious, or on edge?",
  "How often have you been unable to stop or control worrying?",
  "How often have you felt that difficulties were piling up so high that you could not overcome them?"
];

const OPTIONS = [
  { label: "Not at all", score: 0 },
  { label: "Several days", score: 1 },
  { label: "More than half the days", score: 2 },
  { label: "Nearly every day", score: 3 }
];

const Assessment: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnswer = (score: number) => {
    const newAnswers = [...answers, score];
    setAnswers(newAnswers);
    
    if (currentQuestion < QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResult(true);
      generateAnalysis(newAnswers);
    }
  };

  const generateAnalysis = async (finalAnswers: number[]) => {
    setLoading(true);
    const totalScore = finalAnswers.reduce((a, b) => a + b, 0);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `
        The user has completed a mental health screening (similar to PHQ/GAD).
        Their total score is ${totalScore} out of ${QUESTIONS.length * 3}.
        Questions were: ${QUESTIONS.join('; ')}
        Scores (0-3 scale) per question: ${finalAnswers.join(', ')}.
        
        Provide a gentle, empathetic, non-medical summary of their current state. 
        If the score is low, congratulate them on their balance. 
        If high, offer comforting words and suggest they talk to a professional. 
        Provide 2 actionable self-care tips.
        Keep it under 150 words.
        Disclaimer: "I am an AI, not a doctor."
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      setAnalysis(response.text);
    } catch (e) {
      console.error(e);
      setAnalysis("We couldn't generate a detailed analysis right now, but taking this step to check in on yourself is a victory in itself.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setAnswers([]);
    setCurrentQuestion(0);
    setShowResult(false);
    setAnalysis(null);
  };

  const calculateScore = () => answers.reduce((a, b) => a + b, 0);

  return (
    <div className="max-w-3xl mx-auto min-h-[500px] flex flex-col">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Mental Wellness Check-in</h2>
        <p className="text-slate-500">A simple, private way to see how you're doing.</p>
      </div>

      <div className="bg-white/60 backdrop-blur-xl border border-white/60 rounded-3xl p-8 shadow-xl shadow-slate-200/50 flex-1 flex flex-col">
        {!showResult ? (
          <div className="flex-1 flex flex-col">
            {/* Progress Bar */}
            <div className="w-full bg-slate-100 rounded-full h-2 mb-8">
              <div 
                className="bg-teal-500 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${((currentQuestion + 1) / QUESTIONS.length) * 100}%` }}
              ></div>
            </div>

            <div className="flex-1 flex flex-col justify-center">
              <span className="text-teal-600 font-bold tracking-wider text-xs uppercase mb-4">
                Question {currentQuestion + 1} of {QUESTIONS.length}
              </span>
              <h3 className="text-2xl font-semibold text-slate-800 mb-8 leading-relaxed">
                {QUESTIONS[currentQuestion]}
              </h3>

              <div className="grid gap-4">
                {OPTIONS.map((opt) => (
                  <button
                    key={opt.label}
                    onClick={() => handleAnswer(opt.score)}
                    className="group flex items-center justify-between p-5 rounded-2xl border border-white/50 bg-white/40 hover:bg-white/80 hover:border-teal-200 transition-all text-left shadow-sm hover:shadow-md active:scale-[0.99]"
                  >
                    <span className="text-slate-700 font-medium text-lg group-hover:text-teal-700">{opt.label}</span>
                    <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-teal-500" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="animate-fade-in flex-1 flex flex-col items-center text-center space-y-6">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg ${calculateScore() > 8 ? 'bg-orange-100 text-orange-500' : 'bg-teal-100 text-teal-600'}`}>
              <ClipboardCheck className="w-10 h-10" />
            </div>

            <h3 className="text-3xl font-bold text-slate-800">
              Check-in Complete
            </h3>

            {loading ? (
               <div className="flex items-center space-x-2 text-slate-500">
                 <RefreshCw className="animate-spin w-5 h-5" />
                 <span>Generating your personalized insights...</span>
               </div>
            ) : (
               <div className="bg-white/50 rounded-2xl p-8 border border-white/50 shadow-sm w-full text-left">
                  <div className="prose prose-slate max-w-none">
                     <p className="text-slate-700 text-lg leading-relaxed">{analysis}</p>
                  </div>
                  
                  <div className="mt-6 pt-6 border-t border-slate-200/50 flex items-start space-x-3">
                     <AlertTriangle className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                     <p className="text-xs text-slate-400">
                        This assessment is for informational purposes only and does not constitute a medical diagnosis. If you are in crisis, please contact emergency services or a mental health professional immediately.
                     </p>
                  </div>
               </div>
            )}

            <button 
              onClick={reset}
              className="px-8 py-3 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold transition-colors"
            >
              Start Over
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Assessment;