import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Sphere, MeshDistortMaterial, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

interface ThreeAvatarProps {
  volume: number; // 0 to 1
  isUserSpeaking: boolean;
  isModelSpeaking: boolean;
}

const AvatarMesh: React.FC<{ volume: number; isModelSpeaking: boolean }> = ({ volume, isModelSpeaking }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<any>(null);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (meshRef.current) {
      // Gentle floating
      meshRef.current.position.y = Math.sin(time * 0.5) * 0.2;
      
      // Rotation
      meshRef.current.rotation.x = THREE.MathUtils.lerp(meshRef.current.rotation.x, Math.sin(time * 0.2) * 0.1, 0.1);
      meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, time * 0.1, 0.1);

      // Scale based on volume when speaking
      const targetScale = isModelSpeaking ? 1 + volume * 1.5 : 1;
      meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.2);
    }

    if (materialRef.current) {
        // Distort more when speaking
        const targetDistort = isModelSpeaking ? 0.4 + volume : 0.3;
        const targetSpeed = isModelSpeaking ? 5 : 2;
        
        materialRef.current.distort = THREE.MathUtils.lerp(materialRef.current.distort, targetDistort, 0.1);
        materialRef.current.speed = THREE.MathUtils.lerp(materialRef.current.speed, targetSpeed, 0.1);
    }
  });

  return (
    <Sphere args={[1.5, 64, 64]} ref={meshRef}>
      <MeshDistortMaterial
        ref={materialRef}
        color={isModelSpeaking ? "#2dd4bf" : "#818cf8"} // Teal when talking, Soft Indigo idle
        roughness={0.1}
        metalness={0.5}
        distort={0.3}
        speed={2}
      />
    </Sphere>
  );
};

const ThreeAvatar: React.FC<ThreeAvatarProps> = ({ volume, isModelSpeaking }) => {
  return (
    <div className="w-full h-full rounded-3xl overflow-hidden border border-white/60 shadow-xl shadow-slate-200/50 bg-gradient-to-b from-white/40 to-white/10 relative backdrop-blur-xl">
        <div className="absolute top-4 left-4 z-10 px-4 py-1.5 bg-white/60 backdrop-blur-md rounded-full border border-white/50 text-xs font-semibold text-slate-600 shadow-sm">
            {isModelSpeaking ? "Aman is speaking..." : "Listening..."}
        </div>
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        <ambientLight intensity={0.8} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#2dd4bf" />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#c084fc" />
        {/* Replaced Stars with simple background or none for clean look */}
        
        <AvatarMesh volume={volume} isModelSpeaking={isModelSpeaking} />
        
        <OrbitControls enableZoom={false} enablePan={false} autoRotate={false} />
      </Canvas>
    </div>
  );
};

export default ThreeAvatar;