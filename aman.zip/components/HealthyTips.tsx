import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Lightbulb, Bell, BellOff, RefreshCw, Share2 } from 'lucide-react';

const HealthyTips: React.FC = () => {
  const [tip, setTip] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  const fetchTip = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: "Give me a single, short, unique, and actionable mental health tip (max 2 sentences). Focus on mindfulness, stress relief, or positivity. Do not use standard clichés."
      });
      setTip(response.text);
    } catch (e) {
      console.error(e);
      setTip("Take a deep breath. Inhale for 4 seconds, hold for 7, and exhale for 8.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTip();
  }, []);

  const toggleNotifications = () => {
    setNotificationsEnabled(!notificationsEnabled);
    if (!notificationsEnabled) {
      // Simulate permission request
      if (window.Notification && Notification.permission !== 'granted') {
         Notification.requestPermission();
      }
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Daily Wellness Tips</h2>
        <p className="text-slate-500">Bite-sized wisdom to keep your mind balanced throughout the day.</p>
      </div>

      <div className="relative group">
         <div className="absolute -inset-1 bg-gradient-to-r from-amber-200 to-yellow-200 rounded-3xl blur opacity-30 group-hover:opacity-50 transition duration-1000"></div>
         <div className="relative bg-white/70 backdrop-blur-xl border border-white/60 rounded-3xl p-8 shadow-xl shadow-slate-200/50 min-h-[200px] flex flex-col items-center justify-center text-center">
            
            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-6 text-amber-500 shadow-sm">
               <Lightbulb className="w-6 h-6" />
            </div>

            {loading ? (
               <RefreshCw className="animate-spin text-slate-400 w-8 h-8" />
            ) : (
               <p className="text-xl font-medium text-slate-700 leading-relaxed mb-6">
                 "{tip}"
               </p>
            )}

            <div className="flex space-x-3 mt-4">
               <button 
                 onClick={fetchTip} 
                 disabled={loading}
                 className="px-5 py-2 bg-white border border-slate-200 rounded-full text-slate-600 text-sm font-semibold hover:bg-slate-50 transition-colors flex items-center space-x-2"
               >
                 <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
                 <span>New Tip</span>
               </button>
            </div>
         </div>
      </div>

      <div className="bg-white/40 backdrop-blur-md rounded-2xl p-6 border border-white/50 flex items-center justify-between shadow-sm">
         <div className="flex items-center space-x-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${notificationsEnabled ? 'bg-teal-100 text-teal-600' : 'bg-slate-100 text-slate-400'}`}>
               {notificationsEnabled ? <Bell size={20} /> : <BellOff size={20} />}
            </div>
            <div>
               <h4 className="font-semibold text-slate-800">Daily Notifications</h4>
               <p className="text-xs text-slate-500">Get a gentle nudge every 6 hours.</p>
            </div>
         </div>
         
         <button 
           onClick={toggleNotifications}
           className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${notificationsEnabled ? 'bg-teal-500' : 'bg-slate-300'}`}
         >
            <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${notificationsEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
         </button>
      </div>
    </div>
  );
};

export default HealthyTips;